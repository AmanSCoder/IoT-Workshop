# dht11
Working version of the DHT11 library for Arduino

I published this one since there a lots of various versions of the DHT11 library 
for Arduino floating around but most of them do not work with the current version of Arduino IDE.

This version of the library is used in this tutorial:

http://www.makerblog.at/2014/08/dht11-sensor-fuer-temperatur-und-luftfeuchtigkeit-am-arduino/ 

and here:

https://www.youtube.com/watch?v=iTF6__w7AJ8

(German only, sorry)
